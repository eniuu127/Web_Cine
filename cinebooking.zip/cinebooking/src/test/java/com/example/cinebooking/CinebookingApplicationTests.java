package com.example.cinebooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinebookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
