package com.example.cinebooking.DTO.Booking;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SetPaymentMethodRequest {
    private String paymentMethodId;
}
