package com.example.cinebooking.DTO.Room;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RoomDTO {
    private Long roomId;
    private String roomName;
    private String screenType;
}
