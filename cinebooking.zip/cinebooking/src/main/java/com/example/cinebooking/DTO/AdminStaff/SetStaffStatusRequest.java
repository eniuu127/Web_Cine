package com.example.cinebooking.DTO.AdminStaff;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SetStaffStatusRequest {
    private Boolean enabled; // required
}
