package com.example.cinebooking.DTO.Payment;

import lombok.*;

@Getter @Setter
public class PaymentMethodDTO {
    private String code;
    private String name;
}
