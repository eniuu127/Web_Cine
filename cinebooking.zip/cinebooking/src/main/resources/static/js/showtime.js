(function () {
  const datePick = document.getElementById("datePick");
  const btnReload = document.getElementById("btnReload");
  const stGrid = document.getElementById("stGrid");
  const stEmpty = document.getElementById("stEmpty");

  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, m => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[m]));
  }

  function toDateInputValue(d) {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  }

  function fmtTime(iso) {
    // iso: "2026-01-16T11:00:00"
    if (!iso) return "";
    const t = iso.split("T")[1] || "";
    return t.substring(0, 5);
  }

  function money(n) {
    const x = Number(n || 0);
    return x.toLocaleString("vi-VN") + " đ";
  }

  function groupByMovie(list) {
    const map = new Map();
    for (const it of list) {
      const key = it.movieId;
      if (!map.has(key)) map.set(key, { movie: it, items: [] });
      map.get(key).items.push(it);
    }
    // sort movie title
    return Array.from(map.values()).sort((a, b) => (a.movie.title || "").localeCompare(b.movie.title || ""));
  }

  async function load() {
    const date = datePick.value;
    stGrid.innerHTML = "";
    stEmpty.textContent = "Đang tải...";

    try {
      const res = await fetch(`/api/showtimes?date=${encodeURIComponent(date)}`, {
        headers: { "Accept": "application/json" }
      });

      if (!res.ok) {
        stEmpty.textContent = `Lỗi tải lịch chiếu (${res.status}).`;
        return;
      }

      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) {
        stEmpty.textContent = "Không có suất chiếu trong ngày này.";
        return;
      }

      stEmpty.textContent = "";
      const groups = groupByMovie(data);

      stGrid.innerHTML = groups.map(g => {
        const m = g.movie;
        const items = g.items;

        const chips = items.map(st => {
          return `
            <a class="cb-st-chip" href="/showtimes/${st.showtimeId}/seats" title="Chọn ghế">
              <div class="t">${esc(fmtTime(st.startTime))}</div>
              <div class="sub">${esc(st.roomName || "")} • ${esc(st.screenType || "")}</div>
              <div class="p">${money(st.basePrice)}</div>
            </a>
          `;
        }).join("");

        return `
          <div class="cb-st-card">
            <div class="cb-st-left">
              <img class="cb-st-poster" src="${esc(m.posterUrl)}" alt="${esc(m.title)}">
            </div>

            <div class="cb-st-right">
              <div class="cb-st-title">${esc(m.title)}</div>
              <div class="cb-muted" style="margin-top:6px;">Chọn suất chiếu:</div>
              <div class="cb-st-chips">${chips}</div>
            </div>
          </div>
        `;
      }).join("");

    } catch (e) {
      console.error(e);
      stEmpty.textContent = "Không tải được lịch chiếu (lỗi mạng/JS).";
    }
  }

  // init
  datePick.value = toDateInputValue(new Date());
  btnReload.addEventListener("click", load);
  datePick.addEventListener("change", load);

  load();
})();
