// ===== Auth helpers =====
function getToken(){ return localStorage.getItem("cine_token") || sessionStorage.getItem("cine_token"); }
function getRole(){ return localStorage.getItem("cine_role") || sessionStorage.getItem("cine_role"); }

// ===== DOM =====
const navItems = document.querySelectorAll(".nav-item");
const pages = {
  dashboard: document.getElementById("page-dashboard"),
  movies: document.getElementById("page-movies"),
  showtimes: document.getElementById("page-showtimes"),
  rooms: document.getElementById("page-rooms"),
  seats: document.getElementById("page-seats"),
};
const pageTitle = document.getElementById("pageTitle");
const pageDesc = document.getElementById("pageDesc");

const btnRefresh = document.getElementById("btnRefresh");
const btnLogout  = document.getElementById("btnLogout");

const toastEl = document.getElementById("toast");

const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const modalFoot = document.getElementById("modalFoot");
const modalClose = document.getElementById("modalClose");

// Movies
const btnMovieAdd = document.getElementById("btnMovieAdd");
const movieSearch = document.getElementById("movieSearch");
const movieTableBody = document.querySelector("#movieTable tbody");

// KPI
const kpiMovies = document.getElementById("kpiMovies");
const kpiRooms = document.getElementById("kpiRooms");
const kpiShowtimes = document.getElementById("kpiShowtimes");
const movieStatusBreakdown = document.getElementById("movieStatusBreakdown");
const roomTypeBreakdown = document.getElementById("roomTypeBreakdown");

// ===== API =====
const API = ""; // same-origin
async function apiFetch(path, opts = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(opts.headers || {}),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(API + path, { ...opts, headers });
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const t = await res.text();
      if (t) msg = t;
    } catch {}
    throw new Error(msg);
  }
  // try json
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return res.json();
  return res.text();
}

// ===== Toast =====
let toastTimer = null;
function toast(msg, type = "info") {
  toastEl.textContent = msg;
  toastEl.classList.remove("show", "danger", "success");
  if (type === "danger") toastEl.classList.add("danger");
  if (type === "success") toastEl.classList.add("success");
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2400);
}

// ===== Modal =====
function openModal(title, bodyHtml, footHtml) {
  modalTitle.textContent = title;
  modalBody.innerHTML = bodyHtml;
  modalFoot.innerHTML = footHtml;
  modal.classList.remove("hidden");
}
function closeModal() {
  modal.classList.add("hidden");
  modalBody.innerHTML = "";
  modalFoot.innerHTML = "";
}
modalClose.addEventListener("click", closeModal);
modal.addEventListener("click", (e) => {
  if (e.target?.dataset?.close) closeModal();
});

// ===== Navigation =====
function showPage(key) {
  for (const k of Object.keys(pages)) pages[k].classList.add("hidden");
  pages[key].classList.remove("hidden");

  navItems.forEach(b => b.classList.toggle("active", b.dataset.page === key));

  if (key === "dashboard") {
    pageTitle.textContent = "Dashboard";
    pageDesc.textContent  = "Thống kê tổng quan hệ thống";
    loadDashboard().catch(err => toast(err.message, "danger"));
  }
  if (key === "movies") {
    pageTitle.textContent = "Movies";
    pageDesc.textContent  = "CRUD phim (/api/admin/movies)";
    loadMovies().catch(err => toast(err.message, "danger"));
  }
  if (key === "showtimes") {
    pageTitle.textContent = "Showtimes";
    pageDesc.textContent  = "CRUD suất chiếu (/api/admin/showtimes)";
    loadShowtimes().catch(err => toast(err.message, "danger"));
  }
  if (key === "rooms") {
    pageTitle.textContent = "Rooms";
    pageDesc.textContent  = "CRUD phòng chiếu (/api/admin/rooms)";
    loadRooms().catch(err => toast(err.message, "danger"));
  }
  if (key === "seats") {
    pageTitle.textContent = "Seats";
    pageDesc.textContent  = "Generate/Clear seat map (/api/admin/seats)";
    loadSeats().catch(err => toast(err.message, "danger"));
  }
}

navItems.forEach(btn => btn.addEventListener("click", () => showPage(btn.dataset.page)));

// ===== Logout =====
btnLogout.addEventListener("click", () => {
  localStorage.removeItem("cine_token");
  localStorage.removeItem("cine_role");
  sessionStorage.removeItem("cine_token");
  sessionStorage.removeItem("cine_role");
  window.location.replace("./admin_login.html");
});

// ===== Refresh =====
btnRefresh.addEventListener("click", () => {
  const active = document.querySelector(".nav-item.active")?.dataset?.page || "dashboard";
  showPage(active);
});

// ===== Helpers =====
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, m => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[m]));
}

function normalizeYoutubeUrl(url) {
  if (!url) return null;
  url = url.trim();

  // watch?v= -> embed/
  if (url.includes("watch?v=")) return url.replace("watch?v=", "embed/");

  // youtu.be/ -> embed/
  if (url.includes("youtu.be/")) {
    const id = url.split("youtu.be/")[1].split(/[?&]/)[0];
    return "https://www.youtube.com/embed/" + id;
  }
  return url;
}

function badgeHasTrailer(trailerUrl) {
  return trailerUrl && trailerUrl.trim().length > 0;
}

// ===== DASHBOARD =====
async function loadDashboard() {
  // Dùng các list endpoint để thống kê nhanh
  const [movies, rooms, showtimes] = await Promise.all([
    apiFetch("/api/admin/movies"),
    apiFetch("/api/admin/rooms").catch(() => []),
    apiFetch("/api/admin/showtimes").catch(() => []),
  ]);

  kpiMovies.textContent = Array.isArray(movies) ? movies.length : "—";
  kpiRooms.textContent = Array.isArray(rooms) ? rooms.length : "—";
  kpiShowtimes.textContent = Array.isArray(showtimes) ? showtimes.length : "—";

  // breakdown movie status
  if (Array.isArray(movies)) {
    const map = {};
    movies.forEach(m => {
      const st = (m.status || "UNKNOWN").toUpperCase();
      map[st] = (map[st] || 0) + 1;
    });
    movieStatusBreakdown.textContent = Object.entries(map)
      .map(([k,v]) => `${k}: ${v}`)
      .join(" | ") || "—";
  }

  // breakdown room type
  if (Array.isArray(rooms)) {
    const map = {};
    rooms.forEach(r => {
      const st = (r.screenType || "UNKNOWN").toUpperCase();
      map[st] = (map[st] || 0) + 1;
    });
    roomTypeBreakdown.textContent = Object.entries(map)
      .map(([k,v]) => `${k}: ${v}`)
      .join(" | ") || "—";
  }
}

// ===== MOVIES =====
let allMovies = [];

async function loadMovies() {
  const data = await apiFetch("/api/admin/movies");
  allMovies = Array.isArray(data) ? data : [];
  renderMovies(allMovies);
}

function renderMovies(list) {
  movieTableBody.innerHTML = list.map(m => {
    const trailerOk = badgeHasTrailer(m.trailerUrl);
    return `
      <tr>
        <td>${esc(m.movieId ?? m.id)}</td>
        <td>
          <div style="font-weight:800;">${esc(m.title)}</div>
          <div class="muted" style="font-size:12px; word-break:break-all;">${esc(m.posterUrl || "")}</div>
        </td>
        <td>
          ${trailerOk
            ? `<span class="badge" title="Có trailer">▶</span>`
            : `<span class="muted" title="Chưa có trailer">—</span>`
          }
        </td>
        <td>${esc(m.runtime ?? "")}</td>
        <td><span class="badge">${esc(m.status || "")}</span></td>
        <td>
          <button class="btn btn-ghost" data-act="edit" data-id="${esc(m.movieId ?? m.id)}">Edit</button>
          <button class="btn btn-ghost" data-act="status" data-id="${esc(m.movieId ?? m.id)}">Set Status</button>
          <button class="btn btn-danger" data-act="delete" data-id="${esc(m.movieId ?? m.id)}">Delete</button>
        </td>
      </tr>
    `;
  }).join("");
}

// search
movieSearch.addEventListener("input", () => {
  const q = (movieSearch.value || "").trim().toLowerCase();
  const filtered = allMovies.filter(m => (m.title || "").toLowerCase().includes(q));
  renderMovies(filtered);
});

// Add movie
btnMovieAdd.addEventListener("click", () => openMovieModal("create"));

function openMovieModal(mode, movie = null) {
  const isEdit = mode === "edit";
  const title = isEdit ? "Edit Movie" : "Add Movie";

  const body = `
    <div class="field">
      <label>Title</label>
      <input id="mTitle" class="input" placeholder="Movie title" value="${esc(movie?.title || "")}">
    </div>

    <div class="field">
      <label>Poster URL</label>
      <input id="mPosterUrl" class="input" placeholder="https://..." value="${esc(movie?.posterUrl || "")}">
    </div>

    <div class="field">
      <label>Trailer URL (YouTube embed)</label>
      <input id="mTrailerUrl" class="input" placeholder="https://www.youtube.com/embed/XXXX" value="${esc(movie?.trailerUrl || "")}">
      <div class="muted" style="margin-top:6px;">Dán link dạng <b>/embed/</b>. Nếu dán watch?v= hệ thống sẽ tự đổi.</div>
    </div>

    <div class="grid-2">
      <div class="field">
        <label>Runtime (minutes)</label>
        <input id="mRuntime" class="input" type="number" min="1" value="${esc(movie?.runtime ?? 120)}">
      </div>
      <div class="field">
        <label>Status</label>
        <select id="mStatus" class="select">
          ${["NOW_SHOWING","COMING_SOON","SPECIAL","STOPPED"].map(st =>
            `<option value="${st}" ${String(movie?.status||"NOW_SHOWING").toUpperCase()===st ? "selected":""}>${st}</option>`
          ).join("")}
        </select>
      </div>
    </div>
  `;

  const foot = `
    <button class="btn btn-ghost" data-close="1">Cancel</button>
    <button class="btn" id="btnMovieSave">${isEdit ? "Save" : "Create"}</button>
  `;

  openModal(title, body, foot);

  document.getElementById("btnMovieSave").addEventListener("click", async () => {
    try {
      const payload = {
        title: document.getElementById("mTitle").value.trim(),
        posterUrl: document.getElementById("mPosterUrl").value.trim(),
        trailerUrl: normalizeYoutubeUrl(document.getElementById("mTrailerUrl").value),
        runtime: Number(document.getElementById("mRuntime").value || 0),
        status: document.getElementById("mStatus").value
      };

      if (!payload.title) throw new Error("Title is required");
      if (!payload.posterUrl) throw new Error("Poster URL is required");
      if (!payload.runtime || payload.runtime <= 0) throw new Error("Runtime must be > 0");

      if (isEdit) {
        const id = movie.movieId ?? movie.id;
        await apiFetch(`/api/admin/movies/${id}`, { method: "PUT", body: JSON.stringify(payload) });
        toast("Saved movie", "success");
      } else {
        await apiFetch(`/api/admin/movies`, { method: "POST", body: JSON.stringify(payload) });
        toast("Created movie", "success");
      }

      closeModal();
      await loadMovies();
      await loadDashboard().catch(()=>{});
    } catch (err) {
      toast(err.message || "Error", "danger");
    }
  });
}

// table actions
movieTableBody.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-act]");
  if (!btn) return;
  const act = btn.dataset.act;
  const id = btn.dataset.id;

  const movie = allMovies.find(m => String(m.movieId ?? m.id) === String(id));
  if (!movie) return toast("Movie not found", "danger");

  if (act === "edit") {
    openMovieModal("edit", movie);
    return;
  }

  if (act === "delete") {
    if (!confirm(`Delete movie "${movie.title}"?`)) return;
    try {
      await apiFetch(`/api/admin/movies/${id}`, { method: "DELETE" });
      toast("Deleted movie", "success");
      await loadMovies();
      await loadDashboard().catch(()=>{});
    } catch (err) {
      toast(err.message || "Delete failed", "danger");
    }
    return;
  }

  if (act === "status") {
    const newStatus = prompt("Set status (NOW_SHOWING / COMING_SOON / SPECIAL / STOPPED):", movie.status || "NOW_SHOWING");
    if (!newStatus) return;

    try {
      // Endpoint status tùy backend của bạn. Ưu tiên PATCH /{id}/status
      await apiFetch(`/api/admin/movies/${id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status: newStatus })
      });
      toast("Updated status", "success");
      await loadMovies();
      await loadDashboard().catch(()=>{});
    } catch (err) {
      // fallback nếu backend dùng PUT /{id} (cập nhật full)
      try {
        const payload = {
          title: movie.title,
          posterUrl: movie.posterUrl,
          trailerUrl: movie.trailerUrl,
          runtime: movie.runtime,
          status: newStatus
        };
        await apiFetch(`/api/admin/movies/${id}`, { method: "PUT", body: JSON.stringify(payload) });
        toast("Updated status", "success");
        await loadMovies();
        await loadDashboard().catch(()=>{});
      } catch (err2) {
        toast(err2.message || err.message || "Update status failed", "danger");
      }
    }
  }
});

// ===== SHOWTIMES / ROOMS / SEATS =====
// Nếu bạn đang có admin_dashboard.js cũ chạy đủ phần này,
// bạn có thể giữ lại phần cũ. Ở đây mình để tối thiểu để không crash.

async function loadShowtimes() {
  const tb = document.querySelector("#showtimeTable tbody");
  tb.innerHTML = `<tr><td colspan="6" class="muted">Chưa cấu hình UI showtimes trong file JS mới. (Movies đã hoàn thiện trailer)</td></tr>`;
}
async function loadRooms() {
  const tb = document.querySelector("#roomTable tbody");
  tb.innerHTML = `<tr><td colspan="4" class="muted">Chưa cấu hình UI rooms trong file JS mới. (Movies đã hoàn thiện trailer)</td></tr>`;
}
async function loadSeats() {
  // giữ nguyên nếu bạn đã có file cũ; ở đây chỉ tránh lỗi
  const seatRoomSelect = document.getElementById("seatRoomSelect");
  if (seatRoomSelect && seatRoomSelect.options.length === 0) {
    seatRoomSelect.innerHTML = `<option value="">—</option>`;
  }
}

// ===== Init =====
(function init(){
  const role = (getRole() || "").toUpperCase();
  if (role !== "ADMIN") {
    window.location.replace("./admin_login.html");
    return;
  }
  showPage("dashboard");
})();
